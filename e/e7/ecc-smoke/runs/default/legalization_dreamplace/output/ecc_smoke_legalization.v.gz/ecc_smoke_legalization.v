module ecc_smoke (
clk,
rst,
count_0_,
count_1_,
count_2_,
count_3_,
count_4_,
count_5_,
count_6_,
count_7_);

input clk ;
input rst ;
output count_0_ ;
output count_1_ ;
output count_2_ ;
output count_3_ ;
output count_4_ ;
output count_5_ ;
output count_6_ ;
output count_7_ ;

wire clk ;
wire rst ;
wire count_0_ ;
wire count_1_ ;
wire count_2_ ;
wire count_3_ ;
wire count_4_ ;
wire count_5_ ;
wire count_6_ ;
wire count_7_ ;
wire \count[0]_reg_p_D ;
wire \count[1]_reg_p_D ;
wire \count[1]_reg_p_D_AOI21X0P5H7L_Y_B0 ;
wire \count[2]_reg_p_D ;
wire \count[2]_reg_p_D_NOR3X0P5H7L_Y_B ;
wire \count[2]_reg_p_D_NOR3X0P5H7L_Y_C ;
wire \count[3]_reg_p_D ;
wire \count[3]_reg_p_D_AND3X0P5H7L_Y_B ;
wire \count[3]_reg_p_D_AND3X0P5H7L_Y_C ;
wire \count[4]_reg_p_D ;
wire \count[4]_reg_p_D_AOI21X0P5H7L_Y_A0 ;
wire \count[4]_reg_p_D_AOI21X0P5H7L_Y_B0 ;
wire \count[5]_reg_p_D ;
wire \count[5]_reg_p_D_NOR2X0P5H7L_Y_A ;
wire \count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y_A1 ;
wire \count[5]_reg_p_D_NOR2X0P5H7L_Y_B ;
wire \count[6]_reg_p_D ;
wire \count[6]_reg_p_D_AOI21X0P5H7L_Y_A0 ;
wire \count[6]_reg_p_D_AOI21X0P5H7L_Y_A1 ;
wire \count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y_C ;
wire \count[6]_reg_p_D_AOI21X0P5H7L_Y_B0 ;
wire \count[7]_reg_p_D ;
wire \count[7]_reg_p_D_AOI21X0P5H7L_Y_A0 ;
wire \count[7]_reg_p_D_AOI21X0P5H7L_Y_A1 ;
wire \count[7]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND4BBX0P5H7L_Y_AN ;
wire \count[7]_reg_p_D_AOI21X0P5H7L_Y_B0 ;
wire \count[7]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y_A2 ;
wire rst_INVX0P5H7L_A_Y ;
wire cts_flow_clk_0_clk_regular_downstream_net ;
wire cts_flow_clk_0_clk_regular_cluster_sink_net_0 ;


DFFQX0P5H7R \count[0]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[0]_reg_p_D ), .Q(count_0_ ) );
NOR2X0P5H7L \count[0]_reg_p_D_NOR2X0P5H7L_Y ( .A(rst ), .B(count_0_ ), .Y(\count[0]_reg_p_D ) );
DFFQX0P5H7R \count[1]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[1]_reg_p_D ), .Q(count_1_ ) );
AOI21X0P5H7L \count[1]_reg_p_D_AOI21X0P5H7L_Y ( .A0(count_0_ ), .A1(count_1_ ), .B0(\count[1]_reg_p_D_AOI21X0P5H7L_Y_B0 ), .Y(\count[1]_reg_p_D ) );
OAI21X0P5H7L \count[1]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI21X0P5H7L_Y ( .A0(count_0_ ), .A1(count_1_ ), .B0(rst_INVX0P5H7L_A_Y ), .Y(\count[1]_reg_p_D_AOI21X0P5H7L_Y_B0 ) );
DFFQX0P5H7R \count[2]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[2]_reg_p_D ), .Q(count_2_ ) );
NOR3X0P5H7L \count[2]_reg_p_D_NOR3X0P5H7L_Y ( .A(rst ), .B(\count[2]_reg_p_D_NOR3X0P5H7L_Y_B ), .C(\count[2]_reg_p_D_NOR3X0P5H7L_Y_C ), .Y(\count[2]_reg_p_D ) );
AND3X0P5H7L \count[2]_reg_p_D_NOR3X0P5H7L_Y_B_AND3X0P5H7L_Y ( .A(count_0_ ), .B(count_2_ ), .C(count_1_ ), .Y(\count[2]_reg_p_D_NOR3X0P5H7L_Y_B ) );
AOI21X0P5H7L \count[2]_reg_p_D_NOR3X0P5H7L_Y_C_AOI21X0P5H7L_Y ( .A0(count_0_ ), .A1(count_1_ ), .B0(count_2_ ), .Y(\count[2]_reg_p_D_NOR3X0P5H7L_Y_C ) );
DFFQX0P5H7R \count[3]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[3]_reg_p_D ), .Q(count_3_ ) );
AND3X0P5H7L \count[3]_reg_p_D_AND3X0P5H7L_Y ( .A(rst_INVX0P5H7L_A_Y ), .B(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .C(\count[3]_reg_p_D_AND3X0P5H7L_Y_C ), .Y(\count[3]_reg_p_D ) );
NAND4X0P5H7L \count[3]_reg_p_D_AND3X0P5H7L_Y_B_NAND4X0P5H7L_Y ( .A(count_0_ ), .B(count_3_ ), .C(count_2_ ), .D(count_1_ ), .Y(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ) );
AO31X0P5H7L \count[3]_reg_p_D_AND3X0P5H7L_Y_C_AO31X0P5H7L_Y ( .A0(count_0_ ), .A1(count_2_ ), .A2(count_1_ ), .B0(count_3_ ), .Y(\count[3]_reg_p_D_AND3X0P5H7L_Y_C ) );
DFFQX0P5H7R \count[4]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[4]_reg_p_D ), .Q(count_4_ ) );
AOI21X0P5H7L \count[4]_reg_p_D_AOI21X0P5H7L_Y ( .A0(\count[4]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .B0(\count[4]_reg_p_D_AOI21X0P5H7L_Y_B0 ), .Y(\count[4]_reg_p_D ) );
INVX0P5H7L \count[4]_reg_p_D_AOI21X0P5H7L_Y_A0_INVX0P5H7L_Y ( .A(count_4_ ), .Y(\count[4]_reg_p_D_AOI21X0P5H7L_Y_A0 ) );
OAI21X0P5H7L \count[4]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI21X0P5H7L_Y ( .A0(\count[4]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .B0(rst_INVX0P5H7L_A_Y ), .Y(\count[4]_reg_p_D_AOI21X0P5H7L_Y_B0 ) );
DFFQX0P5H7R \count[5]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[5]_reg_p_D ), .Q(count_5_ ) );
NOR2X0P5H7L \count[5]_reg_p_D_NOR2X0P5H7L_Y ( .A(\count[5]_reg_p_D_NOR2X0P5H7L_Y_A ), .B(\count[5]_reg_p_D_NOR2X0P5H7L_Y_B ), .Y(\count[5]_reg_p_D ) );
OAI21X0P5H7L \count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y ( .A0(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .A1(\count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y_A1 ), .B0(rst_INVX0P5H7L_A_Y ), .Y(\count[5]_reg_p_D_NOR2X0P5H7L_Y_A ) );
NAND2X0P5H7L \count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y_A1_NAND2X0P5H7L_Y ( .A(count_4_ ), .B(count_5_ ), .Y(\count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y_A1 ) );
AOI31X0P5H7L \count[5]_reg_p_D_NOR2X0P5H7L_Y_B_AOI31X0P5H7L_Y ( .A0(count_4_ ), .A1(count_3_ ), .A2(\count[2]_reg_p_D_NOR3X0P5H7L_Y_B ), .B0(count_5_ ), .Y(\count[5]_reg_p_D_NOR2X0P5H7L_Y_B ) );
DFFQX0P5H7R \count[6]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[6]_reg_p_D ), .Q(count_6_ ) );
AOI21X0P5H7L \count[6]_reg_p_D_AOI21X0P5H7L_Y ( .A0(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A1 ), .B0(\count[6]_reg_p_D_AOI21X0P5H7L_Y_B0 ), .Y(\count[6]_reg_p_D ) );
INVX0P5H7L \count[6]_reg_p_D_AOI21X0P5H7L_Y_A0_INVX0P5H7L_Y ( .A(count_6_ ), .Y(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A0 ) );
NAND3X0P5H7L \count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y ( .A(count_3_ ), .B(\count[2]_reg_p_D_NOR3X0P5H7L_Y_B ), .C(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y_C ), .Y(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A1 ) );
AND2X0P5H7L \count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y_C_AND2X0P5H7L_Y ( .A(count_4_ ), .B(count_5_ ), .Y(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y_C ) );
OAI31X0P5H7L \count[6]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y ( .A0(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .A2(\count[5]_reg_p_D_NOR2X0P5H7L_Y_A_OAI21X0P5H7L_Y_A1 ), .B0(rst_INVX0P5H7L_A_Y ), .Y(\count[6]_reg_p_D_AOI21X0P5H7L_Y_B0 ) );
DFFQX0P5H7R \count[7]_reg_p ( .CK(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ), .D(\count[7]_reg_p_D ), .Q(count_7_ ) );
AOI21X0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y ( .A0(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A1 ), .B0(\count[7]_reg_p_D_AOI21X0P5H7L_Y_B0 ), .Y(\count[7]_reg_p_D ) );
INVX0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y_A0_INVX0P5H7L_Y ( .A(count_7_ ), .Y(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A0 ) );
NAND4BBX0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND4BBX0P5H7L_Y ( .AN(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND4BBX0P5H7L_Y_AN ), .BN(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .C(\count[2]_reg_p_D_NOR3X0P5H7L_Y_B ), .D(\count[6]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND3X0P5H7L_Y_C ), .Y(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A1 ) );
INVX0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND4BBX0P5H7L_Y_AN_INVX0P5H7L_Y ( .A(count_3_ ), .Y(\count[7]_reg_p_D_AOI21X0P5H7L_Y_A1_NAND4BBX0P5H7L_Y_AN ) );
OAI31X0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y ( .A0(\count[4]_reg_p_D_AOI21X0P5H7L_Y_A0 ), .A1(\count[3]_reg_p_D_AND3X0P5H7L_Y_B ), .A2(\count[7]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y_A2 ), .B0(rst_INVX0P5H7L_A_Y ), .Y(\count[7]_reg_p_D_AOI21X0P5H7L_Y_B0 ) );
NAND3X0P5H7L \count[7]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y_A2_NAND3X0P5H7L_Y ( .A(count_7_ ), .B(count_6_ ), .C(count_5_ ), .Y(\count[7]_reg_p_D_AOI21X0P5H7L_Y_B0_OAI31X0P5H7L_Y_A2 ) );
INVX0P5H7L rst_INVX0P5H7L_A ( .A(rst ), .Y(rst_INVX0P5H7L_A_Y ) );
FILLTAPH7R BNDRY_CAP_1 (  );
FILLTAPH7R BNDRY_CAP_2 (  );
FILLTAPH7R BNDRY_CAP_3 (  );
FILLTAPH7R BNDRY_CAP_4 (  );
FILLTAPH7R BNDRY_CAP_5 (  );
FILLTAPH7R BNDRY_CAP_6 (  );
FILLTAPH7R BNDRY_CAP_7 (  );
FILLTAPH7R BNDRY_CAP_8 (  );
FILLTAPH7R BNDRY_CAP_9 (  );
FILLTAPH7R BNDRY_CAP_10 (  );
FILLTAPH7R BNDRY_CAP_11 (  );
FILLTAPH7R BNDRY_CAP_12 (  );
FILLTAPH7R BNDRY_CAP_13 (  );
FILLTAPH7R BNDRY_CAP_14 (  );
FILLTAPH7R BNDRY_CAP_15 (  );
FILLTAPH7R BNDRY_CAP_16 (  );
FILLTAPH7R BNDRY_CAP_17 (  );
FILLTAPH7R BNDRY_CAP_18 (  );
FILLTAPH7R BNDRY_CAP_19 (  );
FILLTAPH7R BNDRY_CAP_20 (  );
FILLTAPH7R BNDRY_CAP_21 (  );
FILLTAPH7R BNDRY_CAP_22 (  );
FILLTAPH7R WELLTAP_1 (  );
FILLTAPH7R WELLTAP_2 (  );
FILLTAPH7R WELLTAP_3 (  );
FILLTAPH7R WELLTAP_4 (  );
FILLTAPH7R WELLTAP_5 (  );
FILLTAPH7R WELLTAP_6 (  );
FILLCAP4H7R BNDRY_CAP_TAP_1 (  );
FILLCAP4H7R BNDRY_CAP_TAP_2 (  );
FILLCAP32H7R BNDRY_CAP_23 (  );
FILLCAP32H7R BNDRY_CAP_24 (  );
FILLER2H7R BNDRY_CAP_25 (  );
FILLCAP32H7R BNDRY_CAP_26 (  );
FILLCAP32H7R BNDRY_CAP_27 (  );
FILLER2H7R BNDRY_CAP_28 (  );
BUFX8H7L cts_flow_clk_0_clk_regular_root_buf ( .A(clk ), .Y(cts_flow_clk_0_clk_regular_downstream_net ) );
BUFX8H7L cts_flow_clk_0_clk_regular_cluster_buf_0 ( .A(cts_flow_clk_0_clk_regular_downstream_net ), .Y(cts_flow_clk_0_clk_regular_cluster_sink_net_0 ) );

endmodule
